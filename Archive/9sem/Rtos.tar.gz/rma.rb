def main()
d = []
dl = []
n = gets.to_i
n.times do
  d << gets.split.map{|x| x.to_i}
end
max = d[n-1][1]
for i in 0...n
  t = d[i][1]
  while t < max
    dl << t
    t += d[i][1]
  end
end
dl << max
dl = dl.sort.uniq
for i in 0...dl.size
  t = dl[i].to_f
  s = 0
  for j in 0...n
    s += (t/d[j][1]).ceil.to_i*d[j][0].to_i #ceil - окркгление до ближайшего целого 
    puts "#{(t/d[j][1]).ceil.to_i}*#{d[j][0].to_i} "
    if j != n-1
      puts "+ "
    end
  end
  if s > t
    puts " > "
  else
    puts " <= "
  end
  puts " #{t.to_i}\n"
end
main()
