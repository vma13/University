# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Diplom::Application.config.secret_token = '638e448e2a06722051a3a2c98b4f117758f2311ef7656c6ba98acde75e57d562cf50b5ceb8d9fb4108422e2faa6af07a9d992b7c265d43aca71c39a18c75a347'
