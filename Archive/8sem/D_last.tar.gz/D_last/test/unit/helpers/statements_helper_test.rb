require 'test_helper'

class StatementsHelperTest < ActionView::TestCase
end
