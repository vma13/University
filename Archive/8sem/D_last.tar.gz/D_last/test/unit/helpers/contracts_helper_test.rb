require 'test_helper'

class ContractsHelperTest < ActionView::TestCase
end
