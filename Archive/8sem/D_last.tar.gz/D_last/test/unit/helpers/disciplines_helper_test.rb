require 'test_helper'

class DisciplinesHelperTest < ActionView::TestCase
end
