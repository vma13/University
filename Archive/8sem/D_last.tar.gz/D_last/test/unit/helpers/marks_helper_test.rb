require 'test_helper'

class MarksHelperTest < ActionView::TestCase
end
