require 'test_helper'

class SchoolGroupsHelperTest < ActionView::TestCase
end
