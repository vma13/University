require 'test_helper'

class VisitsHelperTest < ActionView::TestCase
end
