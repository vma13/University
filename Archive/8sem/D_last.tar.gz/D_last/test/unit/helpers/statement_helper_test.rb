require 'test_helper'

class StatementHelperTest < ActionView::TestCase
end
