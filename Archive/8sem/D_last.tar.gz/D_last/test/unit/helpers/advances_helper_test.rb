require 'test_helper'

class AdvancesHelperTest < ActionView::TestCase
end
