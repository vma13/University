require 'test_helper'

class SchoolkidsHelperTest < ActionView::TestCase
end
