require 'test_helper'

class MarksTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
