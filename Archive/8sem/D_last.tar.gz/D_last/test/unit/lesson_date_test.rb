require 'test_helper'

class LessonDateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
