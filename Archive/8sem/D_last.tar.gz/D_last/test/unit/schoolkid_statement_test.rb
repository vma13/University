require 'test_helper'

class SchoolkidStatementTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
