require 'test_helper'

class GroupSchoolkidTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
