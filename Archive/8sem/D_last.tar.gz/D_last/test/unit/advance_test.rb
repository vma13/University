require 'test_helper'

class AdvanceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
