require 'test_helper'

class StatementControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
