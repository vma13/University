class GroupSchoolkid < ActiveRecord::Base
   belongs_to :schoolkid
end
